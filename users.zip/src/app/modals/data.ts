export interface Data {
    name: string;
    id: number;
    // status: string;
    // description: string;
    // primary_Email: string;
    // createdAt: string;
  }